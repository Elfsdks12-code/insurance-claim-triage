import json
import hashlib
from pathlib import Path
from typing import Any
from qdrant_client import QdrantClient, models
from sentence_transformers import SentenceTransformer
from config import COLLECTION_NAME, EMBEDDING_MODEL, QDRANT_URL

class HistoricalClaimsRAG:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.client = QdrantClient(url=QDRANT_URL, timeout=10)
        self.encoder = SentenceTransformer(EMBEDDING_MODEL)
        self.vector_size = self.encoder.get_sentence_embedding_dimension()

    def _load_records(self) -> list[dict[str, Any]]:
        # Only historical knowledge-base records are indexed. Ground-truth labels
        # are deliberately never read by runtime retrieval.
        candidates = list((self.data_dir / "knowledge-base").glob("*.json"))
        records = []
        for path in candidates:
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
                if record.get("claim_id") and record.get("description"):
                    records.append(record)
            except (OSError, json.JSONDecodeError):
                continue
        return records

    def ensure_index(self) -> int:
        self.client.get_collections()
        existing = {c.name for c in self.client.get_collections().collections}
        if COLLECTION_NAME not in existing:
            self.client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=models.VectorParams(size=self.vector_size, distance=models.Distance.COSINE),
            )
        records = self._load_records()
        if not records:
            return 0
        points = []
        for record in records:
            text = self._record_text(record)
            vector = self.encoder.encode(text, normalize_embeddings=True).tolist()
            point_id = int(hashlib.sha1(record["claim_id"].encode()).hexdigest()[:15], 16)
            payload = {k: record.get(k) for k in (
                "claim_id", "description", "damage_type", "severity", "affected_areas",
                "resolution", "adjuster_notes", "policy_type", "repair_cost_actual"
            )}
            payload["search_text"] = text
            points.append(models.PointStruct(id=point_id, vector=vector, payload=payload))
        self.client.upsert(collection_name=COLLECTION_NAME, points=points, wait=True)
        return len(points)

    @staticmethod
    def _record_text(record: dict) -> str:
        return " ".join(str(record.get(k, "")) for k in (
            "description", "damage_type", "severity", "affected_areas", "adjuster_notes", "resolution"
        ))

    def search(self, query: str, limit: int = 5) -> list[dict]:
        vector = self.encoder.encode(query, normalize_embeddings=True).tolist()
        # Query API name changed across qdrant-client versions; query_points is
        # supported by the pinned modern client.
        response = self.client.query_points(
            collection_name=COLLECTION_NAME,
            query=vector,
            limit=limit,
            with_payload=True,
        )
        results = []
        for point in response.points:
            payload = point.payload or {}
            results.append({
                "claim_id": payload.get("claim_id", "unknown"),
                "similarity_score": round(float(point.score or 0), 4),
                "resolution_summary": str(payload.get("resolution") or payload.get("adjuster_notes") or "Resolution details unavailable."),
                "damage_type": payload.get("damage_type"),
                "severity": payload.get("severity"),
                "affected_areas": payload.get("affected_areas", []),
            })
        return results
