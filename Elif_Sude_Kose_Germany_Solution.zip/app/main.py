import base64
import io
import time
import uuid
from pathlib import Path
from typing import Optional

import fitz
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError
from qdrant_client import QdrantClient

from agent import get_llm_client, inspect_submission, run_triage, safety_check
from config import DATA_DIR, TOOLS_DIR, QDRANT_URL, MAX_IMAGE_BYTES, MAX_DOCUMENT_BYTES
from rag import HistoricalClaimsRAG
from schemas import IntakeValidation, TriageResponse

app = FastAPI(
    title="Home Damage Claim Triage API",
    version="1.0.0",
    description="Multimodal claim triage with historical-claim retrieval and auditable tool events.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3001", "http://127.0.0.1:3001"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

CLAIMS: dict[str, dict] = {}
TRACES_DB: dict[str, dict] = {}
rag_service: Optional[HistoricalClaimsRAG] = None
qdrant_ready = False

@app.on_event("startup")
def startup():
    global rag_service, qdrant_ready
    try:
        rag_service = HistoricalClaimsRAG(DATA_DIR)
        rag_service.ensure_index()
        qdrant_ready = True
    except Exception as exc:
        # API remains available for diagnostics; retrieval failure is explicit.
        rag_service = None
        qdrant_ready = False
        print(f"RAG initialization failed: {type(exc).__name__}: {exc}")

@app.get("/api/v1/health")
def health_check():
    llm_configured = bool(__import__("config").PORTKEY_API_KEY and __import__("config").LLM_MODEL)
    return {
        "status": "healthy",
        "service": "insurance-triage-api",
        "services": {
            "vector_db": "connected" if qdrant_ready else "disconnected",
            "llm": "configured" if llm_configured else "not_configured",
        },
    }

async def read_upload(upload: UploadFile, max_bytes: int) -> bytes:
    data = await upload.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise HTTPException(status_code=413, detail=f"{upload.filename or 'Upload'} exceeds the size limit.")
    return data

def extract_pdf_text(data: bytes) -> str:
    try:
        with fitz.open(stream=data, filetype="pdf") as pdf:
            return "\n".join(page.get_text("text") for page in pdf)[:20000]
    except Exception:
        raise HTTPException(status_code=400, detail="Supporting document must be a readable PDF.")

def normalize_image(data: bytes, content_type: str) -> tuple[bytes, str]:
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            fmt = (image.format or "").upper()
            mime = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}.get(fmt)
            if not mime:
                raise HTTPException(status_code=400, detail="Upload a JPEG, PNG, or WebP image.")
        return data, mime
    except UnidentifiedImageError:
        raise HTTPException(status_code=400, detail="Uploaded file is not a valid image.")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=400, detail="Uploaded image could not be decoded.")

@app.post("/api/v1/claims/triage")
async def triage_claim(
    description: str = Form(""),
    policy_type: str = Form("standard_homeowner"),
    image: Optional[UploadFile] = File(None),
    images: list[UploadFile] = File(default=[]),
    document: Optional[UploadFile] = File(None),
    file: Optional[UploadFile] = File(None),  # Backward-compatible alias for earlier UI versions.
):
    description = description.strip()
    if policy_type not in {"basic_homeowner", "standard_homeowner", "premium_homeowner", "renters", "landlord"}:
        raise HTTPException(status_code=422, detail="Unsupported policy_type.")
    uploads = ([image] if image and image.filename else []) + [x for x in images if x and x.filename]
    selected_doc = document if document and document.filename else file
    if not uploads and not description:
        raise HTTPException(status_code=400, detail="Provide at least one image or a non-blank description.")

    image_items: list[tuple[bytes, str]] = []
    for upload in uploads[:8]:
        raw = await read_upload(upload, MAX_IMAGE_BYTES)
        raw, mime = normalize_image(raw, upload.content_type or "")
        image_items.append((raw, mime))
    document_text = ""
    if selected_doc and selected_doc.filename:
        if not (selected_doc.filename.lower().endswith(".pdf") or selected_doc.content_type == "application/pdf"):
            raise HTTPException(status_code=400, detail="Supporting document must be a PDF.")
        pdf_bytes = await read_upload(selected_doc, MAX_DOCUMENT_BYTES)
        document_text = extract_pdf_text(pdf_bytes)

    
    try:
        client = get_llm_client()
        validation_raw = inspect_submission(
            client, description, image_items, document_text
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        print(
            f"Intake model error: {type(exc).__name__}: {str(exc)[:1000]}",
            flush=True,
        )
        raise HTTPException(
            status_code=502,
            detail=f"Intake model request failed ({type(exc).__name__}).",
        )

    validation = IntakeValidation(
        is_property_damage=bool(validation_raw.get("is_property_damage", False)),
        is_valid_image=validation_raw.get("is_valid_image") if image_items else None,
        no_pii_detected=bool(validation_raw.get("no_pii_detected", False)),
        no_offensive_content=bool(validation_raw.get("no_offensive_content", False)),
    )

    if not image_items:
        validation.is_valid_image = None

    failed = []
    if not validation.is_property_damage:
        failed.append("Submission does not show or describe property damage.")
    if image_items and not validation.is_valid_image:
        failed.append("Image evidence is not clear or suitable for assessment.")
    if not validation.no_pii_detected:
        failed.append("Personal or payment-card information was detected.")
    if not validation.no_offensive_content:
        failed.append("Submission contains inappropriate or irrelevant content.")
    if failed:
        raise HTTPException(status_code=400, detail={
            "message": "Claim rejected during intake validation: " + " ".join(failed),
            "intake_validation": validation.model_dump(),
        })

    claim_id = str(uuid.uuid4())
    started = time.perf_counter()
    if rag_service is None:
        raise HTTPException(status_code=503, detail="Historical-claim retrieval is not ready; check Qdrant and embedding initialization.")
    try:
        assessment, steps = run_triage(
            client=client,
            description=description,
            image_items=image_items,
            document_text=document_text,
            policy_type=policy_type,
            rag=rag_service,
            tools_dir=TOOLS_DIR,
            claim_id=claim_id,
        )
        safety = safety_check(assessment)
        if not all(safety.model_dump().values()):
            assessment["recommendation"] = "An adjuster should review the evidence and policy wording before any decision."
            safety = safety_check(assessment)
        steps.append({
            "step_number": len(steps) + 1,
            "type": "observe",
            "content": "Output safety checks completed.",
            "tool_name": "safety_checker",
            "tool_output": safety.model_dump(),
        })
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Triage processing failed ({type(exc).__name__}).")

    duration_ms = round((time.perf_counter() - started) * 1000)
    response = {
        "claim_id": claim_id,
        "intake_validation": validation.model_dump(),
        "triage_assessment": assessment,
        "safety_checks": safety.model_dump(),
    }
    CLAIMS[claim_id] = response
    TRACES_DB[claim_id] = {"claim_id": claim_id, "steps": steps, "total_duration_ms": duration_ms}
    return response

@app.get("/api/v1/claims/{claim_id}")
def get_claim(claim_id: str):
    claim = CLAIMS.get(claim_id)
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found.")
    return claim

@app.get("/api/v1/agent/trace/{claim_id}")
def get_agent_trace(claim_id: str):
    trace = TRACES_DB.get(claim_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found for this claim ID.")
    return trace
