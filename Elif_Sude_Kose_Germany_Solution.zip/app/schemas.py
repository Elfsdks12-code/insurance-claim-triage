from typing import Literal, Optional
from pydantic import BaseModel, Field

DamageType = Literal["water_damage", "fire_damage", "storm_damage", "break_in", "vandalism", "other"]
Severity = Literal["minor", "moderate", "severe", "catastrophic"]
Urgency = Literal["low", "medium", "high", "critical"]

class IntakeValidation(BaseModel):
    is_property_damage: bool
    is_valid_image: Optional[bool]
    no_pii_detected: bool
    no_offensive_content: bool

class CostEstimate(BaseModel):
    min: float = Field(ge=0)
    max: float = Field(ge=0)
    currency: str = "USD"

class SimilarClaim(BaseModel):
    claim_id: str
    similarity_score: float = Field(ge=0, le=1)
    resolution_summary: str

class TriageAssessment(BaseModel):
    damage_type: DamageType
    severity: Severity
    affected_areas: list[str]
    damage_description: str
    estimated_repair_cost: CostEstimate
    urgency: Urgency
    recommendation: str
    similar_past_claims: list[SimilarClaim]

class SafetyChecks(BaseModel):
    no_coverage_promises: bool
    no_legal_advice: bool
    no_settlement_amounts: bool
    no_liability_determination: bool
    no_emotional_language: bool

class TriageResponse(BaseModel):
    claim_id: str
    intake_validation: IntakeValidation
    triage_assessment: TriageAssessment
    safety_checks: SafetyChecks

class RejectionDetail(BaseModel):
    message: str
    intake_validation: IntakeValidation
