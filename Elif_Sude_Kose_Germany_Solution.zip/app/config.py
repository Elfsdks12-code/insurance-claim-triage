import os
from pathlib import Path

DATA_DIR = Path(os.getenv("DATA_DIR", "/app/data"))
TOOLS_DIR = Path(os.getenv("TOOLS_DIR", "/app/tools"))
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "historical_claims")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
PORTKEY_BASE_URL = os.getenv("PORTKEY_BASE_URL", "https://portkey.bain.dev/v1").rstrip("/")
PORTKEY_API_KEY = os.getenv("PORTKEY_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "")
MAX_IMAGE_BYTES = int(os.getenv("MAX_IMAGE_BYTES", str(12 * 1024 * 1024)))
MAX_DOCUMENT_BYTES = int(os.getenv("MAX_DOCUMENT_BYTES", str(10 * 1024 * 1024)))
MAX_AGENT_STEPS = int(os.getenv("MAX_AGENT_STEPS", "6"))
