import json
from pathlib import Path
from typing import Any

DAMAGE_TYPES = {"water_damage", "fire_damage", "storm_damage", "break_in", "vandalism", "other"}
SEVERITIES = {"minor", "moderate", "severe", "catastrophic"}
POLICY_TYPES = {"basic_homeowner", "standard_homeowner", "premium_homeowner", "renters", "landlord"}

def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Required lookup file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))

def estimate_repair_cost(tools_dir: Path, damage_type: str, severity: str, affected_areas: list[str]) -> dict:
    """Use the supplied cost table and count each distinct room/component once."""
    data = _read_json(tools_dir / "cost-estimator.json")
    table = data.get("cost_matrix", data.get("costs", data))
    if damage_type not in DAMAGE_TYPES:
        damage_type = "other"
    if severity not in SEVERITIES:
        severity = "moderate"

    # Accept either the assignment's nested min_per_area/max_per_area table
    # or its total_min/total_max table.
    try:
        row = table[damage_type][severity]
        min_per_area = row.get("min_per_area", row.get("total_min"))
        max_per_area = row.get("max_per_area", row.get("total_max"))
    except (KeyError, TypeError):
        raise ValueError(f"Cost table has no entry for {damage_type}/{severity}")

    unique_areas = {str(a).strip().casefold() for a in affected_areas if str(a).strip()}
    multiplier = max(1, len(unique_areas))
    return {
        "min": float(min_per_area) * multiplier,
        "max": float(max_per_area) * multiplier,
        "currency": "USD",
    }

def check_coverage(tools_dir: Path, policy_type: str, incident_category: str) -> dict:
    """Return policy lookup facts only; this is not a coverage decision."""
    data = _read_json(tools_dir / "coverage-table.json")
    policies = data.get("policies", data)
    if policy_type not in POLICY_TYPES:
        return {"covered": False, "deductible": None, "max_payout": None, "notes": "Unknown policy type; adjuster review required."}
    policy = policies.get(policy_type, {})
    covered_categories = policy.get("covered_categories", policy.get("covers", []))
    covered = incident_category in covered_categories
    return {
        "covered": bool(covered),
        "deductible": policy.get("deductible"),
        "max_payout": policy.get("max_payout"),
        "notes": policy.get("notes", policy.get("exclusions", "Refer to the full policy wording.")),
    }
